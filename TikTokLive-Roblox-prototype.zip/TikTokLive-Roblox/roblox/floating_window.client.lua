-- TikTok LIVE Floating Window — UI prototype
-- Place this LocalScript in StarterPlayer > StarterPlayerScripts.
-- NOTE: This does NOT play TikTok LIVE. VideoFrame only accepts Roblox video assets.

local Players = game:GetService("Players")
local UserInputService = game:GetService("UserInputService")

local player = Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")

local oldGui = playerGui:FindFirstChild("TikTokLivePrototype")
if oldGui then oldGui:Destroy() end

local gui = Instance.new("ScreenGui")
gui.Name = "TikTokLivePrototype"
gui.ResetOnSpawn = false
gui.DisplayOrder = 50
gui.Parent = playerGui

local window = Instance.new("Frame")
window.Name = "Window"
window.Size = UDim2.fromOffset(280, 190)
window.Position = UDim2.new(0.65, 0, 0.25, 0)
window.BackgroundColor3 = Color3.fromRGB(22, 22, 29)
window.BorderSizePixel = 0
window.Parent = gui

local windowCorner = Instance.new("UICorner")
windowCorner.CornerRadius = UDim.new(0, 12)
windowCorner.Parent = window

local outline = Instance.new("UIStroke")
outline.Color = Color3.fromRGB(65, 65, 80)
outline.Thickness = 1
outline.Parent = window

local header = Instance.new("Frame")
header.Name = "Header"
header.Size = UDim2.new(1, 0, 0, 36)
header.BackgroundColor3 = Color3.fromRGB(34, 34, 44)
header.BorderSizePixel = 0
header.Active = true
header.Parent = window

local headerCorner = Instance.new("UICorner")
headerCorner.CornerRadius = UDim.new(0, 12)
headerCorner.Parent = header

local title = Instance.new("TextLabel")
title.Size = UDim2.new(1, -112, 1, 0)
title.Position = UDim2.fromOffset(10, 0)
title.BackgroundTransparency = 1
title.Text = "● LIVE  TikTok"
title.TextColor3 = Color3.fromRGB(255, 255, 255)
title.TextSize = 14
title.Font = Enum.Font.GothamBold
title.TextXAlignment = Enum.TextXAlignment.Left
title.Parent = header

local function createButton(name, text, xOffset)
    local button = Instance.new("TextButton")
    button.Name = name
    button.Size = UDim2.fromOffset(28, 26)
    button.Position = UDim2.new(1, xOffset, 0, 5)
    button.BackgroundColor3 = Color3.fromRGB(52, 52, 66)
    button.BorderSizePixel = 0
    button.Text = text
    button.TextColor3 = Color3.new(1, 1, 1)
    button.TextSize = 17
    button.Font = Enum.Font.GothamBold
    button.Parent = header

    local corner = Instance.new("UICorner")
    corner.CornerRadius = UDim.new(0, 6)
    corner.Parent = button
    return button
end

local minimizeButton = createButton("Minimize", "−", -70)
local closeButton = createButton("Close", "×", -36)

local videoFrame = Instance.new("VideoFrame")
videoFrame.Name = "Video"
videoFrame.Position = UDim2.fromOffset(8, 44)
videoFrame.Size = UDim2.new(1, -16, 0, 105)
videoFrame.BackgroundColor3 = Color3.fromRGB(7, 7, 11)
videoFrame.BorderSizePixel = 0
videoFrame.Video = "" -- Optional: rbxassetid://YOUR_ROBLOX_VIDEO_ASSET_ID
videoFrame.Looped = false
videoFrame.Parent = window

local videoCorner = Instance.new("UICorner")
videoCorner.CornerRadius = UDim.new(0, 8)
videoCorner.Parent = videoFrame

local placeholder = Instance.new("TextLabel")
placeholder.Name = "Placeholder"
placeholder.Size = UDim2.fromScale(1, 1)
placeholder.BackgroundTransparency = 1
placeholder.Text = "VIDEO AREA\nTikTok LIVE not connected"
placeholder.TextColor3 = Color3.fromRGB(205, 205, 218)
placeholder.TextSize = 13
placeholder.Font = Enum.Font.GothamMedium
placeholder.Parent = videoFrame

local account = Instance.new("TextLabel")
account.Name = "Account"
account.Position = UDim2.fromOffset(10, 153)
account.Size = UDim2.new(1, -20, 0, 25)
account.BackgroundTransparency = 1
account.Text = "TikTok: @_aid_w"
account.TextColor3 = Color3.fromRGB(180, 180, 195)
account.TextSize = 12
account.Font = Enum.Font.Gotham
account.TextXAlignment = Enum.TextXAlignment.Left
account.Parent = window

local minimized = false
minimizeButton.Activated:Connect(function()
    minimized = not minimized
    videoFrame.Visible = not minimized
    account.Visible = not minimized
    window.Size = minimized and UDim2.fromOffset(180, 36) or UDim2.fromOffset(280, 190)
    minimizeButton.Text = minimized and "+" or "−"
end)

closeButton.Activated:Connect(function()
    gui:Destroy()
end)

-- Dragging with mouse or touch
local dragging = false
local dragStart
local startPosition
local activeInput

header.InputBegan:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseButton1
        or input.UserInputType == Enum.UserInputType.Touch then
        dragging = true
        dragStart = input.Position
        startPosition = window.Position
        activeInput = input

        input.Changed:Connect(function()
            if input.UserInputState == Enum.UserInputState.End then
                dragging = false
            end
        end)
    end
end)

header.InputChanged:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseMovement
        or input.UserInputType == Enum.UserInputType.Touch then
        activeInput = input
    end
end)

UserInputService.InputChanged:Connect(function(input)
    if dragging and input == activeInput then
        local delta = input.Position - dragStart
        window.Position = UDim2.new(
            startPosition.X.Scale,
            startPosition.X.Offset + delta.X,
            startPosition.Y.Scale,
            startPosition.Y.Offset + delta.Y
        )
    end
end)

print("TikTok LIVE UI prototype loaded. TikTok video is not connected.")
