# TikTokLive-Roblox — prototype

This is a UI prototype for a Roblox experience. It does **not** embed a TikTok LIVE stream.

## Current scope
- Floating draggable window
- Minimize / restore / close controls
- VideoFrame placeholder that can play a Roblox-uploaded video asset
- Account label: @_aid_w

## Important limitation
Roblox `VideoFrame` plays video assets uploaded to Roblox. It does not accept a TikTok profile URL, TikTok LIVE URL, HLS URL, or arbitrary webpage URL.

## Install in your own Roblox experience
1. Open your experience in Roblox Studio.
2. Add a `LocalScript` under `StarterPlayer > StarterPlayerScripts`.
3. Copy `roblox/floating_window.client.lua` into it.
4. To test video playback, replace `YOUR_ROBLOX_VIDEO_ASSET_ID` with an ID of a video asset you are authorized to use and that is uploaded to Roblox.
5. Publish/test your own experience.

This project is intended for your own Roblox experience and normal Roblox Studio workflows, not for bypassing Roblox protections or modifying other people's games.
