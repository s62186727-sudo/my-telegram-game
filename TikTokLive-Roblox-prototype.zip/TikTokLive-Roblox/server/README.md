No server is included yet. A server cannot make Roblox VideoFrame accept arbitrary TikTok URLs; validate a supported playback method before building backend infrastructure.
